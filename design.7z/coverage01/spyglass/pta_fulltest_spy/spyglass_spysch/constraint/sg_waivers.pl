################################################################################
#This is an internally genertaed by spyglass to populate Waiver Info for Reports
#Note:Spyglass does not support any perl routine like "spyDecompileWaiverInfo"
#     The routine is purely for internal usage of spyglass
################################################################################


use SpyGlass;

spyClearWaiverHashInPerl(0);

spyDecompileWaiverInfo("waive_cmd_id"=>'1',
                       "-file"=>'m%.*%',
                       "-rule"=>'m%WRN_67%',
                       "-regexp"=>'1',
                       "violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/common/appl/SpyGlass/SpyGlass-4.4.0.6/SPYGLASS_HOME/policies/renesas/renesas_waiver.txt"',
                       "waiverline"=>'12'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'2',
                       "-file"=>'m%.*%',
                       "-rule"=>'m%SGDCWRN_106%',
                       "-regexp"=>'1',
                       "violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/common/appl/SpyGlass/SpyGlass-4.4.0.6/SPYGLASS_HOME/policies/renesas/renesas_waiver.txt"',
                       "waiverline"=>'13'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'3',
                       "-file"=>'m%.*%',
                       "-rule"=>'m%Ac_license01%',
                       "-regexp"=>'1',
                       "violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/common/appl/SpyGlass/SpyGlass-4.4.0.6/SPYGLASS_HOME/policies/renesas/renesas_waiver.txt"',
                       "waiverline"=>'14'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'4',
                       "-file"=>'m%.*%',
                       "-rule"=>'m%checkCMD_ignore02%',
                       "-regexp"=>'1',
                       "violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/common/appl/SpyGlass/SpyGlass-4.4.0.6/SPYGLASS_HOME/policies/renesas/renesas_waiver.txt"',
                       "waiverline"=>'15'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'5',
                       "-file"=>'m%.*%',
                       "-rule"=>'m%Propagate_Clocks%',
                       "-regexp"=>'1',
                       "violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/common/appl/SpyGlass/SpyGlass-4.4.0.6/SPYGLASS_HOME/policies/renesas/renesas_waiver.txt"',
                       "waiverline"=>'18'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'6',
                       "-file"=>'m%.*%',
                       "-rule"=>'m%Propagate_Resets%',
                       "-regexp"=>'1',
                       "violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/common/appl/SpyGlass/SpyGlass-4.4.0.6/SPYGLASS_HOME/policies/renesas/renesas_waiver.txt"',
                       "waiverline"=>'19'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'7',
                       "-file"=>'m%.*%',
                       "-rule"=>'m%Setup_clockreset01%',
                       "-regexp"=>'1',
                       "violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/common/appl/SpyGlass/SpyGlass-4.4.0.6/SPYGLASS_HOME/policies/renesas/renesas_waiver.txt"',
                       "waiverline"=>'20'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'8',
                       "-file"=>'m%.*%',
                       "-rule"=>'m%Reset_check08%',
                       "-regexp"=>'1',
                       "violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/common/appl/SpyGlass/SpyGlass-4.4.0.6/SPYGLASS_HOME/policies/renesas/renesas_waiver.txt"',
                       "waiverline"=>'21'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'9',
                       "-file"=>'m%.*%',
                       "-rule"=>'q%1.2(4)%',
                       "-regexp"=>'1',
                       "violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/shsv/CIS2/internship/201606/3_work/intern4/4_Section4/code/spyglass/rule/verilog_waive.txt"',
                       "waiverline"=>'3'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'10',
                       "-file"=>'m%.*%',
                       "-rule"=>'q%1.2(5)%',
                       "-regexp"=>'1',
                       "violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/shsv/CIS2/internship/201606/3_work/intern4/4_Section4/code/spyglass/rule/verilog_waive.txt"',
                       "waiverline"=>'4'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'11',
                       "-file"=>'m%.*%',
                       "-rule"=>'q%1.2(7)%',
                       "-regexp"=>'1',
                       "violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/shsv/CIS2/internship/201606/3_work/intern4/4_Section4/code/spyglass/rule/verilog_waive.txt"',
                       "waiverline"=>'5'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'12',
                       "-file"=>'m%.*%',
                       "-rule"=>'q%2.2(1)%',
                       "-regexp"=>'1',
                       "violations_waived"=>'29 30 31 32 33 34 35 36 37 38 39 40 41 42 43 44 45 46 47 48 49 50 51 52 53 54 55 56 57 58 59',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/shsv/CIS2/internship/201606/3_work/intern4/4_Section4/code/spyglass/rule/verilog_waive.txt"',
                       "waiverline"=>'7'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'13',
                       "-file"=>'m%.*%',
                       "-rule"=>'q%2.2(2)%',
                       "-regexp"=>'1',
                       "violations_waived"=>'156 157 158 159 160 161 162 163 164 165 166 167 168 169 170 171 172 173 174 175 176 177 178 179 180 181',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/shsv/CIS2/internship/201606/3_work/intern4/4_Section4/code/spyglass/rule/verilog_waive.txt"',
                       "waiverline"=>'8'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'14',
                       "-file"=>'m%.*%',
                       "-rule"=>'q%2.2(3)%',
                       "-regexp"=>'1',
                       "violations_waived"=>'154',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/shsv/CIS2/internship/201606/3_work/intern4/4_Section4/code/spyglass/rule/verilog_waive.txt"',
                       "waiverline"=>'9'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'15',
                       "-file"=>'m%.*%',
                       "-rule"=>'q%2.6(1)%',
                       "-regexp"=>'1',
                       "violations_waived"=>'96 97 98 99 100 101 102 103 104',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/shsv/CIS2/internship/201606/3_work/intern4/4_Section4/code/spyglass/rule/verilog_waive.txt"',
                       "waiverline"=>'10'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'16',
                       "-file"=>'m%.*%',
                       "-rule"=>'q%2.6(2)%',
                       "-regexp"=>'1',
                       "violations_waived"=>'105 106 107 108 109 110 111 112',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/shsv/CIS2/internship/201606/3_work/intern4/4_Section4/code/spyglass/rule/verilog_waive.txt"',
                       "waiverline"=>'11'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'17',
                       "-file"=>'m%.*%',
                       "-rule"=>'q%3.1.2(3)%',
                       "-regexp"=>'1',
                       "violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/shsv/CIS2/internship/201606/3_work/intern4/4_Section4/code/spyglass/rule/verilog_waive.txt"',
                       "waiverline"=>'12'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'18',
                       "-file"=>'m%.*%',
                       "-rule"=>'q%3.1.3(3)%',
                       "-regexp"=>'1',
                       "violations_waived"=>'140 141 142 143 144 145 146',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/shsv/CIS2/internship/201606/3_work/intern4/4_Section4/code/spyglass/rule/verilog_waive.txt"',
                       "waiverline"=>'13'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'19',
                       "-file"=>'m%.*%',
                       "-rule"=>'q%3.1.3(9)%',
                       "-regexp"=>'1',
                       "violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/shsv/CIS2/internship/201606/3_work/intern4/4_Section4/code/spyglass/rule/verilog_waive.txt"',
                       "waiverline"=>'14'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'20',
                       "-file"=>'m%.*%',
                       "-rule"=>'q%3.2.2(5)%',
                       "-regexp"=>'1',
                       "violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/shsv/CIS2/internship/201606/3_work/intern4/4_Section4/code/spyglass/rule/verilog_waive.txt"',
                       "waiverline"=>'15'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'21',
                       "-file"=>'m%.*%',
                       "-rule"=>'q%3.2.5(1)%',
                       "-regexp"=>'1',
                       "violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/shsv/CIS2/internship/201606/3_work/intern4/4_Section4/code/spyglass/rule/verilog_waive.txt"',
                       "waiverline"=>'16'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'22',
                       "-file"=>'m%.*%',
                       "-rule"=>'q%3.2.6(5)%',
                       "-regexp"=>'1',
                       "violations_waived"=>'',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/shsv/CIS2/internship/201606/3_work/intern4/4_Section4/code/spyglass/rule/verilog_waive.txt"',
                       "waiverline"=>'17'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'23',
                       "-file"=>'m%.*%',
                       "-rule"=>'q%3.3(1)%',
                       "-regexp"=>'1',
                       "violations_waived"=>'60 61 62 63 64',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/shsv/CIS2/internship/201606/3_work/intern4/4_Section4/code/spyglass/rule/verilog_waive.txt"',
                       "waiverline"=>'18'
                      );

spyDecompileWaiverInfo("waive_cmd_id"=>'24',
                       "-file"=>'m%.*%',
                       "-severity"=>'m%Info%',
                       "-regexp"=>'1',
                       "violations_waived"=>'3 11 13',
                       "cmd_status"=>'1',
                       "waiverfile"=>'"/shsv/CIS2/internship/201606/3_work/intern4/4_Section4/code/spyglass/rule/verilog_waive.txt"',
                       "waiverline"=>'22'
                      );

spySetWaivedViolationNumberHash("");

1;
