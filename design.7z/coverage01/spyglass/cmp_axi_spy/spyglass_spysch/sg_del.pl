use spyglass;
use SpyGlass;
use SpyGlass::Objects;
&spyGenerateDelViolHash("cmp_axi_spy/spyglass_spysch/sg_msgtag.txt");
1;