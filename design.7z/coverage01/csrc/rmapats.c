#include <stdio.h>
#include <stdlib.h>
#include <strings.h>
#include "rmapats.h"

scalar dummyScalar;
scalar fScalarIsForced=0;
scalar fScalarIsReleased=0;
scalar fScalarHasChanged=0;
void  hsF_0(struct dummyq_struct * I752, EBLK  * I753, U  I560);
void  hsF_0(struct dummyq_struct * I752, EBLK  * I753, U  I560)
{
    U  I944;
    U  I945;
    U  I946;
    struct futq * I947;
    I944 = ((U )vcs_clocks) + I560;
    I946 = I944 & 0xfff;
    I753->I495 = (EBLK  *)(-1);
    I753->I505 = I944;
    if (I944 < (U )vcs_clocks) {
        I945 = ((U  *)&vcs_clocks)[1];
        sched_millenium(I752, I753, I945 + 1, I944);
    }
    else if ((I947 = I752->I726[I946].I514)) {
        I753->I506 = (struct eblk *)I947->I513;
        I947->I513->I495 = (RP )I753;
        I947->I513 = (RmaEblk  *)I753;
    }
    else {
        sched_hsopt(I752, I753, I944);
    }
}
U   hsF_1(U  I764);
U   hsF_1(U  I764)
{
    U  I943 = ffs(I764);
    return  I943 - 1;
}
#ifdef __cplusplus
extern "C" {
#endif
void SinitHsimPats(void);
#ifdef __cplusplus
}
#endif
